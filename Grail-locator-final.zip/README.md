# GRAIL LOCATER ✠

Black-and-chrome, gothic-inspired vintage and archive fashion search. Results appear inside the site; links go to the original listing.

## Structure
- `public/index.html`, `public/_headers`: the website
- `src/worker.js`: Cloudflare Worker entry (serves the site, routes `/api/search`)
- `functions/api/search.js`: eBay Browse API connector
- `wrangler.jsonc`: Cloudflare config (project name must be `grail-locator`)

## What works
Search UI with filters (eBay site/currency, price, condition, item country, size, brand), sorting, load-more, favourites and saved searches (browser localStorage), duplicate removal. The eBay connector is real but **inactive until production keys are added**.

## Not done
- Vinted, Grailed, Depop, Etsy, Vestiaire, Kleinanzeigen, Sellraze, SellSpy: **not connected** (no confirmed public search API; Etsy needs app approval).
- Accounts, alerts, cross-device favourites (Phase 3).
- Prices are not converted between currencies; each search covers one eBay site.

## Deploy
Cloudflare → Workers & Pages → the `grail-locator` project connected to this GitHub repo. It builds from `wrangler.jsonc` automatically on every commit to `main`. Leave build settings at defaults.
Then: Settings → Variables and Secrets → add encrypted `EBAY_CLIENT_ID` and `EBAY_CLIENT_SECRET` (eBay production keys). eBay production keys require handling its marketplace account deletion notice or an exemption (developer.ebay.com).

Independent tool, not affiliated with Chrome Hearts or any marketplace.
